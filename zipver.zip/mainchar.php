<html>
<?php
session_start();
?>
<head>
<title>Home</title>
<link rel = "stylesheet" type = "text/css" href= "style.css">
</head>

<header class = "banner">
	
</header>

<nav>
	<ul>
	<li><a href = "home.php">Home</a></li>
		<li><a href = "aboutus.php">About AT</a></li>
		<li><a href = "mainchar.php">Main Characters</a></li>
		<li><a href = "logout.php">Log Out</a></li>

	
	</ul>
</nav>

<body>
	<article>
	<table cellpadding = 15 class = "mcontainer">
		<tr>
			<td><img src = "finn.png" class ="magnify"></img><br><p>Finn The Human</p></td>
			<td><img src = "jakereal.png" class ="magnify"></img><p><br>Jake the Dog</p></td>
			<td><img src = "pb.png" class ="magnify"></img><br><p>Princess Bubblegum</p></td>
			<td><img src = "iceking.png" class ="magnify"></img><br><p>Ice King</p></td>
			<td><img src = "bmo.png" class ="magnify"></img><br><p>BMO</p></td>
			
		</tr>
		
		
			
	</article>
	</table>
</body>

<footer>
	<p>For more information visit us at<br><brs><a href = "http://www.cartoonnetworkasia.com/"><img class = "babyfinn" src ="babyfinn.png">
</img>
								<img class ="cnlogo" src="cnlogo1.png"></img><img class = "babyfinn" src ="babyfinn.png">
</img></a></p>
</footer>
</html>