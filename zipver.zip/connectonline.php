<?php
mysql_connect("sql208.byetcluster.com","0fe_15757354","f4103sqt") or die ("No database host");
mysql_select_db("0fe_15757354_dbproducts");
?>