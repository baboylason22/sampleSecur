<?php
mysql_connect("localhost","root") or die ("no connection");
mysql_select_db("secur");
?>